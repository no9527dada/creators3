package ct.chapter4;

public class chapter4 {
    public static void load() {
//        BlockFloors.load();
//        CTAttribute.load();
//        CTItem.load();
//        Turrets.load();
//        CTRUnitTypes.load();
//        CTRUnit.load();
//        CTBlocks.load();
//        CTRUnitBlocks.load();
        Planet4.load();
//        ItemTechTrees.load();
//        BlocksTechTrees.load();



        TechTree4.load();
    }
}
