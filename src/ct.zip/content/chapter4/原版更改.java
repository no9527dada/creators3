package ct.chapter4;

import static mindustry.content.StatusEffects.*;

public class 原版更改 {
//燃烧伤害
  /*  public static void load(){
        burning.damage = 0.167f * 1.2f;
    }*/



}
