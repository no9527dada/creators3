package ct.chapter2;

public class chapter2 {
    public static void load() {
        Item2.load();
        Planet2.load();
        TechTree2.load();
    }
}
