package ct.chapter2;

import mindustry.type.Item;
import mindustry.type.Liquid;
import mindustry.world.Block;

public class Blocks2 {
    public static Block 灵脉,
            地板矿物;
    public static Item  天厥石,地参精,炼妖石,混魔石,仙玉,灵魂沙,
            物品;
    public static Liquid 鬼气,人烨,
            液体;
}
