package pixelfactory.content;

import mindustry.world.Block;

//方块
public class 炮塔 {
    public static Block
            炮塔
    ;
    public static void load(){


    }
}