package pixelfactory.content;

import arc.Events;
import arc.graphics.Color;
import arc.math.Mathf;
import arc.scene.event.Touchable;
import arc.scene.ui.layout.Table;
import arc.util.Time;
import mindustry.Vars;
import mindustry.game.EventType;
import mindustry.game.Team;
import mindustry.ui.Styles;

import java.util.concurrent.atomic.AtomicReference;

public class 波次 {
    public boolean 检测器=false;

    public int 显示时间=5;
    public 波次() {
        Events.on(EventType.WorldLoadEvent.class, (ea) -> {
            if (!检测器) {
                检测器 = true;
                Vars.ui.hudGroup.find("skip").clicked(() -> {

                    float 倍数 = Float.parseFloat(Vars.state.rules.tags.get("增加敌对伤害生命倍数") == null ? "0.2" : Vars.state.rules.tags.get("增加敌对伤害生命倍数"));
                    if (倍数 >= 0) {
                        Vars.state.rules.tags.put("增加敌对伤害生命倍数", String.valueOf(倍数 + 0.2f));
                    }
                    ;
                    Vars.state.rules.teams.get(Team.crux).unitDamageMultiplier = 倍数;
                    Vars.state.rules.teams.get(Team.crux).unitHealthMultiplier = 倍数;

                    信息提醒(显示时间, "敌人攻击血量已增加" + String.format("%.2f",倍数 * 10) + "%", Color.white, Color.red);
              /*      float final倍数 = 倍数;
                    Groups.unit.each((e) -> {
                        if (e.team.equals(Team.crux)) {
                            e.health += e.health * final倍数;
                        }
                    });*/
                });
            }
        });

    }
    private void 信息提醒(float sec, String msg, Color color, Color color2) {
        sec *= 60.0F;
        AtomicReference<Float> lifeTime2 = new AtomicReference(sec);
        Table tab = new Table();
        tab.setFillParent(true);
        Table tabl = new Table();
        tabl.collapser((top) -> {
            top.background(Styles.black6).add(msg).pad(8.0F).update((label) -> {
                label.color.set(color).lerp(color2, Mathf.absin(Time.time, 4.0F, 2.0F));
            });
        }, true, () -> {
            if (Vars.state.isPaused()) {
                return false;
            } else if (Vars.state.isMenu()) {
                return false;
            } else {
                lifeTime2.updateAndGet((v) -> {
                    return v - Time.delta;
                });
                return (Float)lifeTime2.get() > 0.0F;
            }
        }).touchable(Touchable.disabled).fillX().row();
        tab.center().bottom().visibility = () -> {
            return Vars.ui.hudfrag.shown;
        };
        tab.marginBottom(350.0F);
        tab.add(tabl);
        Vars.ui.hudGroup.addChild(tab);
    }



}