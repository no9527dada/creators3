package pixelfactory.content;

import arc.struct.Seq;
import mindustry.content.Planets;
import mindustry.content.TechTree;
import mindustry.game.Objectives;


import static pixelfactory.content.工厂.*;
import static pixelfactory.content.星球.PF星球;
import static pixelfactory.content.防御设施.*;
import static mindustry.content.Blocks.*;


public class 科技树 {

    public static void load() {

        PF星球.techTree = TechTree.nodeRoot("像素工业", coreShard, true, () -> {
            //工厂
            科技树Type.addToTree(石英提取机, coreShard);
            科技树Type.addToTree(石英磨练机, 石英提取机);
            科技树Type.addToTree(硫粉发生机, coreShard, null, Seq.with(new Objectives.Research(multiPress)));
            科技树Type.addToTree(爆炸冲击机, 硫粉发生机);
            科技树Type.addToTree(大型粉碎机, coreShard, null, Seq.with(new Objectives.Research(blastMixer)));
            科技树Type.addToTree(碳板压缩机, coreShard, null, Seq.with(new Objectives.Research(multiPress)));
            科技树Type.addToTree(空壳制造机, coreShard, null, Seq.with(new Objectives.Research(multiPress)));
            科技树Type.addToTree(弹药厂_爆破, 空壳制造机);
            科技树Type.addToTree(弹药厂_冷冻, 空壳制造机);
            科技树Type.addToTree(弹药厂_碎裂, 空壳制造机);
            科技树Type.addToTree(弹药厂_硬直, 空壳制造机);
            科技树Type.addToTree(钍电池制造厂, 空壳制造机);
            科技树Type.addToTree(电池转换器, 钍电池制造厂);
            科技树Type.addToTree(多重编织机, coreShard, null, Seq.with(new Objectives.Research(phaseWeaver)));
            科技树Type.addToTree(多重塑钢机, coreShard, null, Seq.with(new Objectives.Research(plastaniumCompressor)));
            科技树Type.addToTree(多重塑钢机, coreShard, null, Seq.with(new Objectives.Research(kiln)));
            科技树Type.addToTree(多重冶炼厂, coreShard, null, Seq.with(new Objectives.Research(siliconSmelter)));
            科技树Type.addToTree(合金锤炼厂, coreShard, null, Seq.with(new Objectives.Research(surgeSmelter)));
            科技树Type.addToTree(铁锻造机, coreShard, null, Seq.with(new Objectives.Research(mechanicalDrill)));
            科技树Type.addToTree(链式锻造机, 铁锻造机);
            科技树Type.addToTree(铁板锻造机, 铁锻造机);
            科技树Type.addToTree(铁板重型加工厂, 铁板锻造机);
            科技树Type.addToTree(铝板合成机, 链式锻造机);
            科技树Type.addToTree(铝板混合器, 铝板合成机);
            科技树Type.addToTree(黄金熔炼器, 铁锻造机);
            科技树Type.addToTree(混合熔炼器, 黄金熔炼器);
            科技树Type.addToTree(钻石离心机, 合金锤炼厂);
            科技树Type.addToTree(钻石矿加工厂, 钻石离心机);
            科技树Type.addToTree(钻石混合物反应机, 黄金熔炼器);
            科技树Type.addToTree(钻石提炼机, 钻石混合物反应机);
            科技树Type.addToTree(相织反应炉, 钻石混合物反应机);
            科技树Type.addToTree(物品厂_水瓶, 空壳制造机);
            科技树Type.addToTree(钛合金反应炉, surgeSmelter);
            科技树Type.addToTree(硫粉发生机, coreShard, null, Seq.with(new Objectives.Research(multiPress)));
            科技树Type.addToTree(放射熔炉, 爆炸冲击机);
            科技树Type.addToTree(固体放射机, 放射熔炉);
            科技树Type.addToTree(放射混合器, blastMixer);
            科技树Type.addToTree(硫粉发生机, coreShard, null, Seq.with(new Objectives.Research(multiPress)));
            科技树Type.addToTree(辐射混合机, 放射熔炉);
            科技树Type.addToTree(辐射混合机, 放射熔炉);
            科技树Type.addToTree(粒子离心机, 矿物离心机);
            科技树Type.addToTree(黎辉离心机, 矿物离心机);
            科技树Type.addToTree(冷冻液发生机, cryofluidMixer);
            科技树Type.addToTree(硫粉发生机, coreShard, null, Seq.with(new Objectives.Research(multiPress)));
            科技树Type.addToTree(制冷液混合机, 冷冻液发生机);
            科技树Type.addToTree(啸动冶炼机, 合金锤炼厂);
            科技树Type.addToTree(军火材料机, 啸动冶炼机);
            科技树Type.addToTree(军火库, 军火材料机);
            科技树Type.addToTree(水晶复合器, 军火材料机);
            科技树Type.addToTree(啸动冲击械, 制冷液混合机);
            科技树Type.addToTree(资源转换器_废料, 铁锻造机);
            科技树Type.addToTree(资源转换器_铜铅, 铁锻造机);
            科技树Type.addToTree(资源转换器_钛, 资源转换器_废料);
            科技树Type.addToTree(资源转换器_钍, 资源转换器_废料);
            科技树Type.addToTree(资源转换器_钴, 资源转换器_废料);
            科技树Type.addToTree(资源转换器_铝, 资源转换器_钴);
            科技树Type.addToTree(资源转换器_塑钢, 资源转换器_钴);

            // 防御设施
            科技树Type.addToTree(铅墙, coreShard, null, Seq.with(new Objectives.Research(copperWall)));
            科技树Type.addToTree(大型铅墙, 铅墙);
            科技树Type.addToTree(硅墙, 大型铅墙);
            科技树Type.addToTree(大型硅墙, 硅墙);
            科技树Type.addToTree(相织硅墙, coreShard, null, Seq.with(new Objectives.Research(phaseWallLarge)));
            科技树Type.addToTree(大型相织硅墙, 相织硅墙);
            科技树Type.addToTree(钴墙, 硅墙);
            科技树Type.addToTree(大型钴墙, 钴墙);
            科技树Type.addToTree(钛合金墙, 钴墙);
            科技树Type.addToTree(大型钛合金墙, 钛合金墙);
            科技树Type.addToTree(巨型钛合金墙, 大型钛合金墙);
            科技树Type.addToTree(超大型钛合金墙, 巨型钛合金墙);

        });
    }
}