package ct.abe;

import mindustry.world.meta.Env;

public class Evn2 extends Env {
    public static final int
            标志0 =  1 << 8,
            标志1 =  1 << 9;
}
