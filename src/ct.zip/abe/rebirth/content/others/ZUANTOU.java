package ct.abe.rebirth.content.others;


import mindustry.world.blocks.production.Drill;
public class ZUANTOU extends Drill {
        public ZUANTOU(String name) {
        super(name);
    }
}
