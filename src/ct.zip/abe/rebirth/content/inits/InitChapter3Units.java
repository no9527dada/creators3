package ct.abe.rebirth.content.inits;

/*
 *@Author:LYBF
 *@Date  :2023/12/25
 */
public class InitChapter3Units {
    /*
     *请在Units类里面定义Unit,在这里赋值
     * 如：
     * Units.java
     * ....
     * public static Unit testUnit
     *
     * Init......java
     * load(){
     *   testUnit = new UnitType(){...}
     * }
     */
    public static void load(){

    }
}
