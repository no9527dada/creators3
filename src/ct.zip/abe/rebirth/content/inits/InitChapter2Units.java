package ct.abe.rebirth.content.inits;

import static ct.abe.rebirth.content.Blocks.*;
import static ct.abe.rebirth.content.Items.*;
import static ct.abe.rebirth.content.Bullets.*;

public class InitChapter2Units {
    /*
     *请在Units类里面定义Unit,在这里赋值
     * 如：
     * Units.java
     * ....
     * public static Unit testUnit
     *
     * Init......java
     * load(){
     *   testUnit = new UnitType(){...}
     * }
     */
    public static void load() {
    }
}
