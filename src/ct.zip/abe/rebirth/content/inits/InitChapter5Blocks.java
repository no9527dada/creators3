package ct.abe.rebirth.content.inits;

/*
 *初始化章节五
 */
public class InitChapter5Blocks {
    /*
     *请在Blocks类里面定义Block,在这里赋值
     * 如：
     * Blocks.java
     * ....
     * public static Block tesBlocks
     *
     * Init......java
     * load(){
     *   testBlocks = new Block(){...}
     * }
     */

    public static void load(){

    }
}
