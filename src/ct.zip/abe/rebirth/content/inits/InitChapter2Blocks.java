package ct.abe.rebirth.content.inits;


import static ct.abe.rebirth.content.Blocks.*;
public class InitChapter2Blocks {
    /*
     *请在Blocks类里面定义Block,在这里赋值
     * 如：
     * Blocks.java
     * ....
     * public static Block tesBlocks
     *
     * Init......java
     * load(){
     *   testBlocks = new Block(){...}
     * }
     */
    public static void load(){

    }
}
