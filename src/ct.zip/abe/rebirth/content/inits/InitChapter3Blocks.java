package ct.abe.rebirth.content.inits;

/*
 *@Author:LYBF
 *@Date  :2023/12/25
 */
public class InitChapter3Blocks {
    /*
     *请在Blocks类里面定义Block,在这里赋值
     * 如：
     * Blocks.java
     * ....
     * public static Block tesBlocks
     *
     * Init......java
     * load(){
     *   testBlocks = new Block(){...}
     * }
     */
    public static void load(){

    }
}
