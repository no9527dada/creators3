package ct.abe.rebirth.content.inits;

/*
 *@Author:LYBF
 *@Date  :2023/12/25
 */
public class InitChapter5Items {
    /*
     *请在Items类里面定义Items,在这里赋值
     * 如：
     * Items.java
     * ....
     * public static Items item
     *
     * Init......java
     * load(){
     *   items = new Item(){...}
     * }
     */
    public static void load(){

    }
}
