package ct.abe.rebirth.meta;

import mindustry.world.meta.Attribute;

import static mindustry.world.meta.Attribute.add;

public class 地形加成 {
    public static final Attribute 灵力收集 = add("灵力收集");
}
