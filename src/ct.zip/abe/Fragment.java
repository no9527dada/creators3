package ct.abe;

import arc.scene.Group;

public abstract class Fragment {
    public abstract void build(Group parent);
}
