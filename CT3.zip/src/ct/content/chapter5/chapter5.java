package ct.content.chapter5;


public class chapter5 {
    public static void load() {
       // 资源5.load();//已经在主类加载
        单位5.load();
        工厂5.load();
        物流5.load();
        电力5.load();
        钻头水泵5.load();
        防御设施5.load();
        炮塔5.load();

        //战役5.load();还没做
        Planet5.load();
        TechTree5.load();
        // 原版修改5.load();
    }
}
