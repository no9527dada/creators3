package ct.content.chapter4;

public class chapter4 {
    public static void load() {

       //CT3Item4.load();//已经在主类加载
        CTR3Unit4.load();
        CT3Blocks4.load();
        CTRUnitBlocks.load();
        Planet4.load();
        TechTree4.load();
    }
}
