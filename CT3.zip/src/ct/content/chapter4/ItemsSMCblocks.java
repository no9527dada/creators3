package ct.content.chapter4;

import mindustry.type.Item;
import mindustry.world.Block;

/*建筑资源器*/
public class ItemsSMCblocks {
    public static Item 冶炼器;
    public static Block
            方块制作器;

    public static void load(){
        冶炼器 = new Item("冶炼器") {};



    }
}
