package ct.content.chapter3;

public class chapter3 {
    public static void load() {
        Planet3.load();
        TechTree3.load();
    }
}
