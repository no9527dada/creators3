package ct.content.chapter2;

import mindustry.type.Item;
import mindustry.type.Liquid;
import mindustry.world.Block;

public class Blocks2 {
    public static Block 灵脉,
            地板矿物;

}
