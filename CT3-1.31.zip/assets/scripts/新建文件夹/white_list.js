//白名单列表
//在括号里写上需要使用的MOD名字，使用英文引号并用英文逗号隔开
//示例："coreunloader-mod","drilling-platform-x","Cheats in v7"，"Ender Chest-末影箱"
exports.whiteList =["creators", "origin_blueprint","creatorupdata",]
//  "Archive_proper_recovery"