const {
    oiljinglianchang, taihejinji, zuanshiyasuoji, jinhuiyasuoji, zhiwujingyoutilianji, zhiwujingyoutiquji, jinhuiyeji,
    xitilianji, zuankuangjiagongchang, meitantiliangongchang, zhiwudaosuiji, fensuiji, liuji,
    hejinboliji, jinhuiboliji,
    shiyingronglu, guijingtichengxingji, guilu, guijingtihechengji, guijingtigongchang,
    shimoxiji, budingjiagongchang, budingjiagongchang2, jinfentilianji, jinchengxingji, jinchengxingji2,
    zijinggongchang, jiweijinggongchang1, jiweijinggongchang2, jiweijinggongchang3, jiweijinggongchang4,
    jiweijinggongchang5, weijingfenjieji, jiweijinggongchang21, liziduizhuangji,
    duochonbuji2, duochonbuji3, duochongsugangji, moliyeshoujiqi1, moliyeshoujiqi2, wenshiqi, zhisuanji,
    zhiwucuiqugongchang, zhiwucuiqugongchang2, feiliaoji, zhuanhuantai, zizhuanTu, tanbanyasuoji, zuanjingjiagongchang,
    tanbanyasuoji2, gaojipeiyangji, molishizhizaoqi, monengjingdamoji0, jimonengjinglianzhiqi1, jimonengjinglianzhiqi2,
    jimonengjinglianzhiqi3, jimonengjinglianzhiqi4, hejin2, luzhayasuoji, jitilianji3, jitilianji4, jitilianjimoliyetilianji,
    xiaofentilianji, zhayaozhizaoji, jhgtbzwj, qianghuaronglu, lengdongyehunheji, moliyehunheji, molijinghuatilianji,
    liziyeji, yuanwanjinghuaji, qiangxiaolengqueyehunheji, chuangshiji, chuangxingjiexiyi, chuangshiyujie, jinbigongcang, weichenshoujiqi,
    chuangshizhishen, choujiangji, wupinyuan, testC, testA, fashetai0, fashetai,CuangShenBubble,
} = require('Blocks/Blocks-factory');
const NO = Fx.none

fensuiji.craftEffect = NO
liuji.craftEffect = NO
guilu.craftEffect = NO
shimoxiji.craftEffect = NO
xitilianji.craftEffect = NO
hejinboliji.craftEffect = NO
zhiwujingyoutilianji.craftEffect = NO
zhiwudaosuiji.craftEffect = NO
jinhuiboliji.craftEffect = NO
jiweijinggongchang2.craftEffect = NO
jiweijinggongchang3.craftEffect = NO
jiweijinggongchang4.craftEffect = NO
jiweijinggongchang5.craftEffect = NO
weijingfenjieji.craftEffect = NO
jiweijinggongchang21.craftEffect = NO
testC.craftEffect = NO
testA.craftEffect = NO
zuanshiyasuoji.craftEffect = NO
taihejinji.craftEffect = NO
duochonbuji2.craftEffect = NO
shiyingronglu.updateEffect = NO
guijingtichengxingji.updateEffect = NO
guijingtigongchang.updateEffect = NO
xitilianji.updateEffect = NO
budingjiagongchang.updateEffect = NO
budingjiagongchang2.updateEffect = NO
hejinboliji.updateEffect = NO
jinhuiboliji.updateEffect = NO
guijingtihechengji.updateEffect = NO
zhiwujingyoutiquji.updateEffect = NO
guilu.updateEffect = NO
jinfentilianji.updateEffect = NO
jinchengxingji.updateEffect = NO
jinchengxingji2.updateEffect = NO
zijinggongchang.updateEffect = NO
jiweijinggongchang1.updateEffect = NO
jiweijinggongchang2.updateEffect = NO
jiweijinggongchang3.updateEffect = NO
jiweijinggongchang4.updateEffect = NO
jiweijinggongchang4.coolEffect = NO
jiweijinggongchang5.updateEffect = NO
weijingfenjieji.updateEffect = NO
jiweijinggongchang21.updateEffect = NO
liziduizhuangji.updateEffect = NO
testC.updateEffect = NO
testA.updateEffect = NO
zuanshiyasuoji.updateEffect = NO
taihejinji.updateEffect = NO
oiljinglianchang.updateEffect = NO
jinhuiyasuoji.updateEffect = NO
jinhuiyeji.updateEffect = NO
duochonbuji3.craftEffect = NO
duochongsugangji.craftEffect = NO
feiliaoji.craftEffect = NO
zhuanhuantai.craftEffect = NO
zizhuanTu.craftEffect = NO
zuankuangjiagongchang.craftEffect = NO
meitantiliangongchang.craftEffect = NO
gaojipeiyangji.craftEffect = NO
jimonengjinglianzhiqi2.craftEffect = NO
jimonengjinglianzhiqi3.craftEffect = NO
hejin2.craftEffect = NO
luzhayasuoji.craftEffect = NO
zhayaozhizaoji.craftEffect = NO
jhgtbzwj.craftEffect = NO
jinbigongcang.craftEffect = NO
duochongsugangji.updateEffect = NO
wenshiqi.updateEffect = NO
feiliaoji.updateEffect = NO
zhuanhuantai.updateEffect = NO
zizhuanTu.updateEffect = NO
tanbanyasuoji.updateEffect = NO
zuanjingjiagongchang.updateEffect = NO
zuankuangjiagongchang.updateEffect = NO
meitantiliangongchang.updateEffect = NO
tanbanyasuoji2.updateEffect = NO
molishizhizaoqi.updateEffect = NO
monengjingdamoji0.updateEffect = NO
jimonengjinglianzhiqi1.updateEffect = NO
jimonengjinglianzhiqi2.updateEffect = NO
jimonengjinglianzhiqi3.updateEffect = NO
jimonengjinglianzhiqi4.updateEffect = NO
hejin2.updateEffect = NO
xiaofentilianji.updateEffect = NO
zhayaozhizaoji.updateEffect = NO
jhgtbzwj.updateEffect = NO
qianghuaronglu.updateEffect = NO
zhisuanji.updateEffect = NO
yuanwanjinghuaji.updateEffect = NO
qiangxiaolengqueyehunheji.updateEffect = NO
chuangshiji.updateEffect = NO
chuangxingjiexiyi.updateEffect = NO
chuangshiyujie.updateEffect = NO
jinbigongcang.updateEffect = NO




