package ctrebirth.type;

public class CTRStorageBlock {
}
