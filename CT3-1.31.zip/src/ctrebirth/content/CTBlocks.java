package ctrebirth.content;

import arc.files.Fi;
import arc.graphics.Color;
import ctrebirth.type.CreatorsMultiCrafter;
import ctrebirth.type.CreatorsRecipe;
import mindustry.Vars;
import mindustry.content.Fx;
import mindustry.content.StatusEffects;
import mindustry.gen.Building;
import mindustry.gen.Sounds;
import mindustry.graphics.CacheLayer;
import mindustry.graphics.Shaders;
import mindustry.type.Category;
import mindustry.type.ItemStack;
import mindustry.type.LiquidStack;
import mindustry.world.Block;
import mindustry.world.blocks.defense.Wall;
import mindustry.world.blocks.environment.Floor;
import mindustry.world.blocks.environment.OreBlock;
import mindustry.world.blocks.environment.StaticWall;
import mindustry.world.blocks.environment.SteamVent;
import mindustry.world.blocks.power.BeamNode;
import mindustry.world.blocks.power.ConsumeGenerator;
import mindustry.world.blocks.power.ThermalGenerator;
import mindustry.world.blocks.production.GenericCrafter;
import mindustry.world.blocks.production.Separator;
import mindustry.world.consumers.ConsumeItemFlammable;
import mindustry.world.draw.DrawDefault;
import mindustry.world.draw.DrawLiquidTile;
import mindustry.world.draw.DrawMulti;
import mindustry.world.draw.DrawRegion;
import mindustry.world.meta.Attribute;
import mindustry.world.meta.BuildVisibility;
import mindustry.world.meta.Stat;
import mindustry.world.meta.StatUnit;

import static ctrebirth.content.CTItem.*;
import static mindustry.content.Blocks.iceSnow;
import static mindustry.content.Items.copper;
import static mindustry.type.ItemStack.with;

public class CTBlocks {
    public static float T1time = 60f / 1f;
    public static float T2time = 60f / 1.5f;
    public static float T3time = 60f / 2.8f;
    public static float p1t = 1 / 60f;
    public static float p2t = 3 / 60f;
    public static float p3t = 6 / 60f;

    public static Fi shaders = Vars.mods.locateMod("ctrebirth").root.child("CTshaders");
    public static Shaders.SurfaceShader s1 = new Shaders.SurfaceShader(Shaders.getShaderFi("screenspace.vert").readString(),
            shaders.child("cryofluid2.frag").readString());
    public static CacheLayer.ShaderLayer m = new CacheLayer.ShaderLayer(s1);
        static{
        CacheLayer.add(m);
    }

    public static Block
            //地板：
            冥矿, 魂矿, 冤藤矿, 魔力石, 赤焰石矿, 戾气赤焰石墙矿, 气丝晶体墙矿, 灵石矿, 怨石矿, 烟冰矿, 沉石矿, 微晶石矿,硅晶矿,
            灵液地板, 黑油地板, 黑油喷口, 叹酸地板, 叮浆地板,
    //墙壁
    墙壁,
    //工厂：
    油泵, 黑油精炼台, 夜灵核心融合器, 珊绒透筛器, 珊绒重组器, 青羊子收集器, 暗物质羽窃器,

    //电力
    十字能量节点,小小能量节点,能量节点,能量收集器,能量发生器,
    能源储蓄块制造器,充能器,能源释放器,

    方块;
    public static void load() {


        魂矿 = new OreBlock("魂矿", 魂石) {{//铜矿
            oreDefault = true;
            oreThreshold = 0.81f;
            oreScale = 23.47619f;
        }};
        冥矿 = new OreBlock("冥矿", 冥石) {{//铁矿
            oreDefault = true;
            oreThreshold = 0.81f;
            oreScale = 23.47619f;
        }};
        冤藤矿 = new OreBlock("冤藤墙", 冤藤) {{//煤矿

        }};
        怨石矿 = new OreBlock("怨石矿", 怨石) {{//石头

        }};
        赤焰石矿 = new OreBlock("赤焰石矿", 赤焰石) {{//硅矿

        }};
        灵石矿 = new OreBlock("灵石矿", 灵石) {{//钛石

        }};
        烟冰矿 = new OreBlock("烟土矿", 烟冰) {{//可燃冰矿

        }};
        戾气赤焰石墙矿 = new OreBlock("戾气赤焰石墙矿", 戾气赤焰石) {{//分型硅矿
            wallOre = true;//应用墙壁矿
        }};

        沉石矿 = new StaticWall("沉石矿") {{//金伯利矿石
            itemDrop = 沉石;//直接墙壁矿
            variants = 3;
        }};
        气丝晶体墙矿 = new OreBlock("气丝晶体墙矿", 气丝晶体) {{//刺笋结晶
            wallOre = true;//应用墙壁矿
        }};
        硅晶矿 = new StaticWall("硅晶矿") {{//有机晶体
            itemDrop = 硅晶体;//直接墙壁矿
            variants = 3;
        }};
        微晶石矿 = new StaticWall("微晶石矿") {{//光珊石
            itemDrop = 微晶石;//直接墙壁矿
            variants = 3;
        }};

        魔力石 = new OreBlock("魔力石", 魔能晶) {{//单极磁石矿

        }};

        灵液地板 = new Floor("LingYeFloor") {{
            speedMultiplier = 0.5f;
            variants = 6;
            status = StatusEffects.wet;
            statusDuration = 90f;
            liquidDrop = 灵液;
            isLiquid = true;
            cacheLayer = CacheLayer.water;
            albedo = 0.9f;
            supportsOverlay = true;
            emitLight = true;
            lightRadius = 20;
            lightColor = Color.valueOf("395cf2").a(0.3f);
        }};

        黑油地板 = new Floor("HeiYouFloor") {{
            drownTime = 230f;
            status = StatusEffects.tarred;
            statusDuration = 240f;
            speedMultiplier = 0.19f;
            variants = 0;
            liquidDrop = 黑油;
            isLiquid = true;
            cacheLayer = CacheLayer.tar;

        }};
        黑油喷口 = new SteamVent("HeiYouVent") {{
            parent = blendGroup = 黑油地板;
            attributes.set(CTAttribute.Vent, 1f);//地形限制与加成
            //attributes.set(Attribute.oil, 1.8f);
            effect = Fx.ventSteam;
            effectColor = Color.valueOf("3C3C3C");
            effectSpacing = 60f;

        }};
        叹酸地板 = new Floor("TanSuanFloor") {{
            drownTime = 230f;
            status = StatusEffects.melting;
            statusDuration = 240f;
            // speedMultiplier = 0.19f;
            variants = 4;
            liquidDrop = 叹酸;
            //cacheLayer = CacheLayer.slag;
           // attributes.set(Attribute.heat, 0.85f);

            emitLight = true;
            lightRadius = 40f;
            //lightColor = Color.valueOf("53AE3C64");
            lightColor = Color.valueOf("53AE3C").a(0.15f);

            playerUnmineable = true;
            speedMultiplier = 0.5F;
            cacheLayer = CacheLayer.arkycite;
            drownTime = 60;
            isLiquid = true;
            hasShadow = false;
            // expanded= true;
        }};
        叮浆地板 = new Floor("DingJangFloor") {{
            drownTime = 230f;
            status = StatusEffects.melting;
            statusDuration = 240f;
            speedMultiplier = 0.19f;
            variants = 4;
            liquidDrop = 叮浆;
            isLiquid = true;
           // cacheLayer = CacheLayer.water;
            cacheLayer = m;
            attributes.set(Attribute.heat, 0.85f);
            emitLight = true;
            lightRadius = 40f;
            lightColor = Color.valueOf("c74713").a(0.4f);
        }};
        墙壁 = new StaticWall("墙壁") {{
            variants = 2;
            iceSnow.asFloor().wall = this;//???
            albedo = 0.6f;
        }};


        ItemsSMChunJu.load();//魂矩器
        ItemsSMCyeLian.load();//资源冶炼器
        ItemsSMC.load();//资源合成台
        //ItemsSMCjingLian.load();//精炼台 有问题 要修
        ItemsSMChuaGong.load();//  资源炼化器


        油泵 = new ThermalGenerator("油泵") {{
            requirements(Category.power, with(copper, 30));
            size = 3;
            attribute = CTAttribute.Vent;//地形限制与加成

            displayEfficiencyScale = 1f / 9f;
            minEfficiency = 9f - 0.0001f;
            powerProduction = 3f / 9f;
            displayEfficiency = true;
            generateEffect = Fx.turbinegenerate;
            effectChance = 0.04f;
                   liquidCapacity = 20f;
            fogRadius = 3;
            ambientSound = Sounds.hum;
            ambientSoundVolume = 0.06f;
//            drawer = new DrawMulti(new DrawDefault(), new DrawBlurSpin("-rotator", 0.6f * 9f){{
//                blurThresh = 0.01f;
//            }});

            hasLiquids = true;
            outputLiquid = new LiquidStack(黑油, 5f / 60f / 9f);

           // researchCost = with(Items.beryllium, 15);//科技研究资源费用
        }};
        黑油精炼台 = new GenericCrafter("黑油精炼台") {{
            requirements(Category.crafting, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
            hasItems = true;
            hasPower = true;
            outputItem = new ItemStack(珊绒, 1);
            outputLiquid = new LiquidStack(恐油, 2f / 60f);
            // envEnabled |= Env.space;
            craftTime = 4f * 60f;
            size = 3;
            itemCapacity = 16;
            consumePower(150f / 60f);
            consumeLiquid(黑油, 4f / 60f);
            //consumeItems(with(衬光束, 2, 灵珠, 4, 暗珊绒, 8));
        }};
        夜灵核心融合器 = new GenericCrafter("夜灵核心融合器") {{
            requirements(Category.crafting, with(
                    翠灵晶, 30,
                    混沌晶体, 25,
                    夜灵, 12,
                    缜相织, 40,
                    气光散, 20
            ));
            hasItems = true;
            hasPower = true;
            outputItem = new ItemStack(夜灵核心, 1);
            // envEnabled |= Env.space;
            craftTime = 60f * 8f / T1time;
            size = 3;
            itemCapacity = 16;
            consumePower(650f / 60f);
            consumeItems(with(衬光束, 2, 灵珠, 4, 暗珊绒, 8));
        }};
        珊绒透筛器 = new Separator("珊绒透筛器") {{
            requirements(Category.crafting, with(
                    冥翠块, 25,
                    怨石块, 40,
                    怨气集束, 30,
                    灵魂核心, 10
            ));
            results = with(
                    珊绒, 50,
                    暗珊绒, 1
            );
            itemCapacity = 2;
            hasPower = true;
            craftTime = 7f;
            size = 4;
            consumeItem(珊绒);
            consumePower(90f / 60f);
            consumeLiquid(叮浆, 1f / 60f);

            drawer = new DrawMulti(new DrawRegion("-bottom"), new DrawLiquidTile(), new DrawRegion("-spinner", 3, true), new DrawDefault());
        }};
        珊绒重组器 = new GenericCrafter("珊绒重组器") {{
            requirements(Category.crafting, with(
                    翠灵晶, 30,
                    混沌晶体, 25,
                    灵魂核心, 12,
                    缜相织, 40,
                    气光散, 20
            ));
            hasItems = true;
            hasPower = true;
            outputItem = new ItemStack(暗珊绒, 6);
            craftTime = 60f * 3f;
            size = 3;
            itemCapacity = 24;
            consumePower(1500f / 60f);
            consumeItems(with(珊绒, 12));
        }};
      /*  青羊子收集器 = new GenericCrafter("青羊子收集器") {{//这个工厂要重写
            requirements(Category.crafting, with(
                    翠灵晶, 60,
                    混沌晶体, 35,
                    夜灵核心, 10,
                    魔能晶, 40,
                    灵魂束缚容器, 20
            ));
            hasItems = true;
            hasPower = true;
            outputItem = new ItemStack(青羊子, 1);
            craftTime = 60f * 20f;
            size = 3;
            // consumePower(1500f/60f);
            /// consumeItems(with(珊绒, 12));
        }};*/
        暗物质羽窃器 = new GenericCrafter("暗物质羽窃器") {{
            requirements(Category.crafting, with(
                    翠灵晶, 30,
                    混沌晶体, 32,
                    夜灵珠, 30,
                    缜相织, 70,
                    夜灵核心, 20,
                    微格晶, 10,
                    魔能晶, 50
            ));
            hasItems = true;
            hasPower = true;
            outputItems = ItemStack.with(珊绒, 1, 暗物质, 2);
            craftTime = 60f * 2f;
            size = 4;
            consumePower(4000f / 60f);
            consumeItems(with(青羊子, 3));
        }};



        //电力

        十字能量节点 = new BeamNode("十字能量塔") {{
            size = 1;
           range = 25;
           fogRadius = 3;
           health = 320;
           hasPower = true;
           outputsPower = true;
           consumesPower = true;
           consumePowerBuffered(800);
           buildVisibility = BuildVisibility.shown;
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
        }};
        小小能量节点 = new CreatorsPowerField("小小能量塔") {{
            laserRange = 8f;
            consumesPower = true;
            insulated = false;
            health = 80;
            size = 1;
            drawAlphaA = 0.0f;
            drawAlphaB = 1f;
            drawColor = Color.valueOf("000000");
            drawColor2 = Color.valueOf("26ffec");//Team.sharded.color;
            consumePower(10f / 60f);
            buildVisibility = BuildVisibility.shown;
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
        }};
        能量节点 = new CreatorsPowerField("能量塔") {{
            laserRange = 15f;
            consumesPower = true;
            insulated = false;
            health = 200;
            size = 2;
            drawAlphaA = 0.0f;
            drawAlphaB = 1f;
            drawColor = Color.valueOf("000000");
            drawColor2 = Color.valueOf("26ffec"); //Team.sharded.color;
            consumePower(10f / 60f);
            buildVisibility = BuildVisibility.shown;
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
        }};
        能量收集器 = new Wall("能量收集器") {
            public void setStats() {
                super.setStats();
                stats.add(Stat.basePowerGeneration, 60, StatUnit.powerSecond);
            }{
            health = 120;
            size = 3;
            conductivePower=true;//可以导电
            hasPower = true;
            consumesPower = false;
            outputsPower = true;
            buildType = () -> new Building(){
                public float getPowerProduction(){
                    return 1.0f;
                }
            };
            buildVisibility = BuildVisibility.shown;
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
        }};

        能量发生器 = new ConsumeGenerator("能量发生器") {{
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
            consumeLiquid(灵液, 0.15f);
            itemDuration = 100;
            size = 4;
            itemCapacity = 5;
            powerProduction = 300/60f;
            consume(new ConsumeItemFlammable());
           // consumeItems(with(冥翠, 6,赤焰膏精,6,缜相织,1));
        }};

        能源储蓄块制造器 = new GenericCrafter("能源储蓄块制造器") {{
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
            outputItem = new ItemStack(空电池, 1);
            craftTime = 60f * 3f;
            size = 3;
            itemCapacity = 20;
            consumePower(1500f / 60f);
            consumeItems(with(冥翠, 6,赤焰膏精,6,缜相织,1));
        }};
        充能器 = new GenericCrafter("充能器") {{
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
            outputItem = new ItemStack(满电池, 1);
            craftTime = 60f * 5f;
            size = 3;
            itemCapacity = 20;
            consumePower(500f / 60f);
            consumeItems(with(空电池, 1,一级燃魂集,1));
        }};
        能源释放器 = new CreatorsMultiCrafter("能源释放器",1){{//发电数值没算好
            requirements(Category.power, with(
                    copper, 30,
                    copper, 25,
                    copper, 12,
                    copper, 40,
                    copper, 20
            ));
            size = 3;
            hasItems = true;
            hasPower = true;
            TableColor = Color.valueOf("78ffa5");
            allRecShow = false;
            RecipeShowIS = 1;
            addRecipe(
                    new CreatorsRecipe.InputContents(ItemStack.with(满电池, 1), 0),
                    new CreatorsRecipe.OutputContents(ItemStack.with(空电池, 1),(2000f / 60f+0.0001f)), 60f * 2f
            );
        }};













































    }
}
