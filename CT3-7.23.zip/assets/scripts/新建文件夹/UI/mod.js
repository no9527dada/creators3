let mod = Vars.mods.getMod("creators")
let version = mod.meta.version
const meta = Vars.mods.locateMod("creators").meta;
meta.author = "[pink]N[cyan]O [red]95[violet]27";
meta.description ="version:"+ version+"\n\n"+Core.bundle.format("9527-description")
//Vars.mods.locateMod("creators").meta.version += "----" + Core.bundle.format("planet.creators.MODname");//本地








