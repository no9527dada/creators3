const suand =Attribute.add("suand")
exports.suand =suand