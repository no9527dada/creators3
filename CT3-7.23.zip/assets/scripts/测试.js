exports.fensuiji =
    (() => {
        // const a = extend(CreatorsNoChooseMulti, "fensuiji", 2, {});
        const a =CTBlocks.测试
        // new 多合成不后台("测试", 3);
        a.TableColor = Color.white;
        a.addRecipe(
            new CreatorsRecipe.InputContents(ItemStack.with(Items.lead, 5), 0),
            new CreatorsRecipe.OutputContents(ItemStack.with(Items.copper, 14)), 30.0,
        );
        a.addRecipe(
            new CreatorsRecipe.InputContents(ItemStack.with(Items.graphite, 5), 0),
            new CreatorsRecipe.OutputContents(ItemStack.with(Items.titanium, 8)), 30.0,
        );
        a.addRecipe(
            new CreatorsRecipe.InputContents(ItemStack.with(), 1),
            new CreatorsRecipe.OutputContents(ItemStack.with(Items.silicon, 2)), 200.0,
        );
        a.health = 360;
        a.size = 2;
        a.itemCapacity = 30;
        a.buildCostMultiplier = 0.3;
        a.craftEffect = Fx.pulverizeMedium;
        a.updateEffect = Fx.none;
        a.requirements = ItemStack.with(
       
        );
        a.group = BlockGroup.transportation
        a.buildVisibility = BuildVisibility.shown;
        a.ambientSound = Sounds.machine;
        a.category = Category.crafting;
        return a;
    })();
