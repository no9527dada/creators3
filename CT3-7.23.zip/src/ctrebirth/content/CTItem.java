package ctrebirth.content;

import arc.files.Fi;
import arc.graphics.*;
import arc.struct.*;
import mindustry.Vars;
import mindustry.graphics.CacheLayer;
import mindustry.graphics.Shaders;
import mindustry.type.*;
import mindustry.type.Liquid;
import mindustry.content.*;
import mindustry.world.Block;
import mindustry.world.blocks.environment.*;


import static mindustry.content.Blocks.*;

/**
 * @author WOW
 * @date 2022/10/04
 * 存放全部物品
 */
public class CTItem {
    //注册物品/液体 变量
    public static Item
            /*矿物*/
            魂石, 冥石, 冤藤, 赤焰石, 戾气赤焰石, 气丝晶体, 灵石, 怨石, 烟冰, 沉石, 微晶石,
    /*合成物*/
    棺炆魂矩,
            赤水魂矩,
            止枢魂矩,
            绝情魂矩,
            混仑魂矩,
            灵屈魂矩,
            魂翠, 冥翠, 相织物, 粉烟, 气光散, 灵魂丝, 沉珠, 冥翠块, 灵珠,
            赤焰膏块, 赤焰膏精, 怨气集束, 怨灵集束, 灵晶, 灵魂束缚容器, 夜灵珠,
            怨石块, 灵魂网束器, 微格晶, 珊绒, 暗珊绒, 冥丝, 灵境, 气丝节束, 魂冲器,
            青羊子, 暗物质, 冥织, 微相织, 衬相织, 缜相织, 灵魂集束, 灵魂核心, 网束器,
            衬光束, 夜灵, 夜灵核心, 灵魂转换因子, 魂力激发块, 硅晶体, 魔能晶, 翠灵晶,
            混沌晶体, 一级燃魂集, 二级燃魂集, 三级燃魂集,空电池,满电池,
    /*掉落物*/
    神花碎片,

    物品;


    public static Liquid
            灵液, 黑油, 恐油, 叹酸, 叮浆,

    液体;


    public static final Seq<Item> serpuloItems = new Seq<>(), erekirItems = new Seq<>(), erekirOnlyItems = new Seq<>();


    public static void load() {

        /*jinhuiboli = new Item("jinhuiboli",Color.valueOf("F3D272")){{
           hardness = 1;//硬度
           buildable = false;//禁止进入核心
            charge = 0.3f;//放电性，被破坏产生电弧
            frames = 8;// >0时会有有动画
            transitionFrames = 1;//每帧之间生成的过渡帧的数量
            frameTime = 10f;//贴图变换之间的时间，默认5
        }};*/
        棺炆魂矩 = new Item("棺炆魂符", Color.valueOf("ffffff")) {{//蓝

        }};
        赤水魂矩 = new Item("赤水魂符", Color.valueOf("ffffff")) {{//红

        }};
        止枢魂矩 = new Item("止枢魂符", Color.valueOf("ffffff")) {{//黄

        }};
        绝情魂矩 = new Item("绝情魂符", Color.valueOf("ffffff")) {{//紫

        }};
        混仑魂矩 = new Item("混仑魂符", Color.valueOf("ffffff")) {{//绿

        }};
        灵屈魂矩 = new Item("灵屈魂符", Color.valueOf("ffffff")) {{//白

        }};

        神花碎片 = new Item("神花碎片", Color.valueOf("ffffff")) {{
            frames = 50;// >0时会有有动画
            transitionFrames = 1;//每帧之间生成的过渡帧的数量
            frameTime = 4f;//贴图变换之间的时间，默认5
        }};



        魂石 = new Item("魂石", Color.valueOf("ffffff")) {{//铜999
            buildable = false;
            charge = 0.3f;
            hardness = 1;
        }};
        冥石 = new Item("冥石", Color.valueOf("ffffff")) {{//铁999
            buildable = false;
            hardness = 1;
        }};
        冤藤 = new Item("冤藤", Color.valueOf("ffffff")) {{//煤999
            flammability = 1f;
            buildable = false;
            hardness = 1;
        }};
        怨石 = new Item("怨石", Color.valueOf("ffffff")) {{//石头999
            buildable = false;
            hardness = 1;
        }};
        赤焰石 = new Item("赤焰石", Color.valueOf("ffffff")) {{//硅999
            buildable = false;
            hardness = 1;
        }};
        戾气赤焰石 = new Item("戾气赤焰石", Color.valueOf("ffffff")) {{//分型硅999
            buildable = false;
            hardness = 1;
        }};
        烟冰 = new Item("烟冰", Color.valueOf("ffffff")) {{//可燃冰
            flammability = 0.8f;
            buildable = false;
            hardness = 1;
        }};
        灵石 = new Item("灵石", Color.valueOf("ffffff")) {{//钛石999
            buildable = false;
            hardness = 1;
        }};
        气丝晶体 = new Item("气丝晶体", Color.valueOf("ffffff")) {{//刺笋结晶
            buildable = false;
            hardness = 1;
        }};

        沉石 = new Item("沉石", Color.valueOf("ffffff")) {{//金伯利矿石
            buildable = false;
            hardness = 1;
        }};
        微晶石 = new Item("微晶石", Color.valueOf("ffffff")) {{//光珊石
            buildable = false;
            hardness = 1;
        }};
        魔能晶 = new Item("魔能晶", Color.valueOf("ffffff")) {{//单极磁石

        }};



        魂翠 = new Item("魂翠", Color.valueOf("ffffff")) {{//铜板999

        }};
        冥翠 = new Item("冥翠", Color.valueOf("ffffff")) {{//铁板999

        }};
        冥织 = new Item("冥织", Color.valueOf("ffffff")) {{//磁铁999

        }};
        怨石块 = new Item("怨石块", Color.valueOf("ffffff")) {{//石板999

        }};
        怨气集束 = new Item("怨气集束", Color.valueOf("ffffff")) {{//玻璃999

        }};
        粉烟 = new Item("粉烟", Color.valueOf("ffffff")) {{//石墨999
            flammability = 1.5f;
        }};
        冥翠块 = new Item("冥翠块", Color.valueOf("ffffff")) {{//钢材999

        }};
        赤焰膏块 = new Item("赤焰膏块", Color.valueOf("ffffff")) {{//硅板999

        }};
        赤焰膏精 = new Item("赤焰膏精", Color.valueOf("ffffff")) {{//晶格硅999

        }};

        灵珠 = new Item("灵珠", Color.valueOf("ffffff")) {{//钛板999

        }};
        沉珠 = new Item("沉珠", Color.valueOf("ffffff")) {{//金刚石999

        }};
        翠灵晶 = new Item("翠灵晶", Color.valueOf("ffffff")) {{//钛合金999

        }};
/***************/
        冥丝 = new Item("冥丝", Color.valueOf("ffffff")) {{//齿轮999

        }};
        相织物 = new Item("相织物", Color.valueOf("ffffff")) {{//线圈 999

        }};
        微相织 = new Item("微相织", Color.valueOf("ffffff")) {{//电动机999

        }};
        衬相织 = new Item("衬相织", Color.valueOf("ffffff")) {{//电磁涡轮999

        }};
        缜相织 = new Item("缜相织", Color.valueOf("ffffff")) {{//超级磁场环999

        }};
        灵境 = new Item("灵境", Color.valueOf("ffffff")) {{//棱镜999

        }};
        灵魂丝 = new Item("灵魂丝", Color.valueOf("ffffff")) {{//电路板999

        }};
        硅晶体 = new Item("硅晶体", Color.valueOf("ffffff")) {{//有机晶体999
            buildable = false;
            hardness = 1;
        }};
        灵晶 = new Item("灵晶", Color.valueOf("ffffff")) {{//钛晶石999
            flammability = 1.8f;
        }};
        魂力激发块 = new Item("魂力激发块", Color.valueOf("ffffff")) {{//电浆激发器999

        }};
        一级燃魂集 = new Item("一级燃魂集", Color.valueOf("ffffff")) {{
            flammability = 3f;
        }};
        二级燃魂集 = new Item("二级燃魂集", Color.valueOf("ffffff")) {{
            flammability = 5f;
           // alwaysUnlocked = true;
        }};
        三级燃魂集 = new Item("三级燃魂集", Color.valueOf("ffffff")) {{
            flammability = 12f;

        }};
        空电池 = new Item("能源储蓄块(空)", Color.valueOf("ffffff")) {{

        }};
        满电池 = new Item("能源储蓄块(满)", Color.valueOf("ffffff")) {{

        }};
        怨灵集束 = new Item("怨灵集束", Color.valueOf("ffffff")) {{//钛化玻璃999

        }};
        微格晶 = new Item("微格晶", Color.valueOf("ffffff")) {{//卡西米尔晶体999

        }};
        灵魂集束 = new Item("灵魂集束", Color.valueOf("ffffff")) {{//微晶元件999

        }};
        灵魂核心 = new Item("灵魂核心", Color.valueOf("ffffff")) {{//处理器999

        }};
        灵魂转换因子 = new Item("灵魂转换因子", Color.valueOf("ffffff")) {{//位面过滤器999

        }};
        夜灵 = new Item("夜灵", Color.valueOf("ffffff")) {{//量子芯片999

        }};
        灵魂网束器 = new Item("灵魂网束器", Color.valueOf("ffffff")) {{//粒子带宽999

        }};
        夜灵珠 = new Item("夜灵珠", Color.valueOf("ffffff")) {{//引力透镜999

        }};
        衬光束 = new Item("衬光束", Color.valueOf("ffffff")) {{//粒子容器//999
            frames = 7;// >0时会有有动画
            transitionFrames = 1;//每帧之间生成的过渡帧的数量
            frameTime = 10f;//贴图变换之间的时间，默认5
        }};
        灵魂束缚容器 = new Item("灵魂束缚容器", Color.valueOf("ffffff")) {{//泯灭约束球999

        }};
        混沌晶体 = new Item("混沌晶体", Color.valueOf("ffffff")) {{//框架材料999

        }};
        魂冲器 = new Item("魂冲器", Color.valueOf("ffffff")) {{//地基??

        }};
        /*============*/
        夜灵核心 = new Item("夜灵核心", Color.valueOf("ffffff")) {{//奇异物质999

        }};


/*================*/

        网束器 = new Item("网束器", Color.valueOf("ffffff")) {{//塑料999
            flammability = 1.5f;
        }};
        气光散 = new Item("气光散", Color.valueOf("ffffff")) {{//石墨烯999
            flammability = 1.3f;
        }};
        珊绒 = new Item("珊绒", Color.valueOf("ffffff")) {{//氢
            flammability = 0.2f;
        }};
        气丝节束 = new Item("气丝节束", Color.valueOf("ffffff")) {{//纳米碳管999

        }};
        暗珊绒 = new Item("暗珊绒", Color.valueOf("ffffff")) {{//重氢
            flammability = 0.5f;
        }};
        青羊子 = new Item("青羊子", Color.valueOf("ffffff")) {{//光子999

        }};
        暗物质 = new Item("暗物质", Color.valueOf("ffffff")) {{//反物质999

        }};











        灵液 = new Liquid("灵液", Color.valueOf("718cff")) {{
            flammability = 0f;
            temperature = 0f;
            heatCapacity = 0.6f;
            viscosity = 0.2f;
            explosiveness = 0f;
           // lightColor = Color.valueOf("153ff2").a(0.3f);
            lightColor = Color.valueOf("0097f5").a(0.2f);
            gasColor = Color.valueOf("c1e8f5");
        }};
        黑油 = new Liquid("黑油", Color.valueOf("000000")) {{
            viscosity = 0.75f;
            flammability = 1.2f;
            explosiveness = 1.2f;
            heatCapacity = 0.7f;
            barColor = Color.valueOf("6b675f");
            effect = StatusEffects.tarred;
            boilPoint = 0.65f;
            gasColor = Color.grays(0.4f);
            canStayOn.add(灵液);
        }};
        恐油 = new Liquid("恐油", Color.valueOf("3f2e67")) {{
            gas = true;
            barColor = Color.valueOf("3f2e67");
            flammability = 0f;
            temperature = 0f;
            heatCapacity = 0.6f;
            viscosity = 0.2f;
            explosiveness = 0f;
        }};
        叹酸 = new Liquid("叹酸", Color.valueOf("53AE3C")) {{
            flammability = 0f;
            temperature = 0f;
            heatCapacity = 0.6f;
            viscosity = 0.2f;
            explosiveness = 0f;
            lightColor = Color.valueOf("25ee16").a(0.2f);
        }};
        叮浆 = new Liquid("叮浆", Color.valueOf("c74713")) {{
            temperature = 1f;
            viscosity = 0.7f;
            effect = StatusEffects.melting;
            lightColor = Color.valueOf("c74713").a(0.4f);
        }};


        //定义变量为物品/液体属性
       /* shiying = new Item("shiying", Color.valueOf("ffffff")){{
            hardness = 2;
        }};
        guijingti = new Item("guijingti",Color.valueOf("DDDDFF")){{
        }};
        shimoxi = new Item("shimoxi",Color.valueOf("3419ff")){{
        }};
        hejinboli = new Item("hejinboli",Color.valueOf("F3D272")){{
            charge = 0.3f;//放电性，被破坏产生电弧
        }};
        jinhuiboli = new Item("jinhuiboli",Color.valueOf("F3D272")){{
            charge = 0.3f;//放电性，被破坏产生电弧
            frames = 8;// >0时会有有动画
            transitionFrames = 1;//每帧之间生成的过渡帧的数量
            frameTime = 10f;//贴图变换之间的时间，默认5
        }};
        xudianchi = new Item("xudianchi",Color.valueOf("F3D272")){{
            charge = 1;//放电性，被破坏产生电弧
        }};
        jingliantai = new Item("jingliantai",Color.valueOf("CECEFF")){{
            hardness = 3;
        }};
        taihejin = new Item("taihejin",Color.valueOf("B8C9FF")){{

        }};
        buding = new Item("buding",Color.valueOf("FFD59E")){{

        }};
        hua1 = new Item("1hua",Color.valueOf("FF0080")){{
            flammability = 0.2f;
        }};
        hua2 = new Item("2hua",Color.valueOf("EA0000")){{
            flammability = 0.2f;
        }};
        hua3 = new Item("3hua",Color.valueOf("2828FF")){{
            flammability = 0.2f;
        }};
        zhiwumo = new Item("zhiwusuimo",Color.valueOf("487a51")){{
            flammability = 0.5f;
        }};
        canza = new Item("canza",Color.valueOf("487a51")){{
            flammability = 0.5f;
        }};
        kuangzajinghuawu = new Item("kuangzajinghuawu",Color.valueOf("842B00")){{

        }};
        tanban = new Item("tanban",Color.valueOf("2a2a27")){{
            flammability = 2;
        }};
        zuanshikuang = new Item("zuankuang",Color.valueOf("006030")){{
            hardness = 7;
        }};
        zuanjing = new Item("zuanjing",Color.valueOf("4EFEB3")){{

        }};
        xiao = new Item("xiao",Color.valueOf("E0E0E0")){{
            flammability = 1;
        }};
        zhayao = new Item("zhayao",Color.valueOf("FF2D2D")){{
            flammability = 0.7f;
            explosiveness = 5;
        }};
        gutaiwanqin = new Item("gutaiwanqin",Color.valueOf("E598EE")){{
            flammability = 0.78f;
            explosiveness = 3;
        }};
        juhebaozhawu = new Item("juhebaozhawu",Color.valueOf("f10fff")){{
            flammability = 1.5f;
            explosiveness = 3;
            radioactivity = 0.3f;
        }};
        JHhejin = new Item("JHhejin",Color.valueOf("E8D123")){{

        }};
        jinfen = new Item("jinfen",Color.valueOf("FFE153")){{

        }};
        jin = new Item("jin",Color.valueOf("FFE153")){{
            hardness = 4;
        }};
        zijing1 = new Item("zijing1",Color.valueOf("9F35FF")){{

        }};
        weijing1 = new Item("weijing1",Color.valueOf("FFFF6F")){{

        }};
        weijing2 = new Item("weijing2",Color.valueOf("53FF53")){{

        }};
        weijing3 = new Item("weijing3",Color.valueOf("ffa6ff")){{

        }};
        weijing4 = new Item("weijing4",Color.valueOf("FF8000")){{
            hardness = 12;
        }};
        weijing5 = new Item("weijing5",Color.valueOf("FF5809")){{

        }};
        molizhi = new Item("molizhi",Color.valueOf("921AFF")){{
            radioactivity = 1;
        }};
        molishi = new Item("molishi",Color.valueOf("272727")){{
            radioactivity = 1.4f;
            hardness = 10;
        }};
        monengjing = new Item("monengjing",Color.valueOf("3C3C3C")){{
            radioactivity = 1.6f;
        }};
        monengjing1 = new Item("monengjing1",Color.valueOf("28004D")){{
            radioactivity = 1.8f;
        }};
        monengjing2 = new Item("monengjing2",Color.valueOf("aa67ff")){{
            radioactivity = 2.1f;
        }};
        monengjing3 = new Item("monengjing3",Color.valueOf("f51212")){{
            radioactivity = 2.5f;
        }};
        chuangshilizi = new Item("chuangshilizi",Color.valueOf("E1E100")){{

        }};
        chuangshiweichen = new Item("chuangshiweichen",Color.valueOf("ffffff")){{

        }};
        chuangshizhixing = new Item("chuangshizhixing",Color.valueOf("ffffff")){{

        }};
        yuanshencanpian = new Item("yuanshencanpian",Color.valueOf("EA0000")){{

        }};
        mieshishenhun = new Item("mieshishenhun",Color.valueOf("EA0000")){{

        }};
        chuangshishenhun = new Item("chuangshishenhun",Color.valueOf("EA0000")){{

        }};
        zzjinbi = new Item("zz-jinbi",Color.valueOf("f4bc57")){{

        }};
        matrix3 = new Item("3matrix",Color.valueOf("ffffff")){{
            alwaysUnlocked = true;
        }};
        matrix4 = new Item("4matrix",Color.valueOf("ffffff")){{
            alwaysUnlocked = true;
        }};
        matrix5 = new Item("5matrix",Color.valueOf("ffffff")){{
            alwaysUnlocked = true;
        }};
        matrix6 = new Item("6matrix",Color.valueOf("ffffff")){{
            alwaysUnlocked = true;
        }};
        dabaoshui = new Item("dabaoshui",Color.valueOf("529eff")){{

        }};
        dabaoleng = new Item("dabaoleng",Color.valueOf("1fc9ff")){{

        }};
        dabaoshiyou = new Item("dabaoshiyou",Color.valueOf("000000")){{

        }};
        dabaojinglianlio = new Item("dabaojinglianlio",Color.valueOf("6b675f")){{

        }};
        dabaomoli = new Item("dabaomoli",Color.valueOf("881fff")){{

        }};
        dabaozhiwujingyou = new Item("dabaozhiwujingyou",Color.valueOf("2f5d42")){{

        }};
        dabaozhiwu = new Item("dabaozhiwu",Color.valueOf("73f58a")){{

        }};
        dabaojingmoli = new Item("dabaojingmoli",Color.valueOf("d296fb")){{

        }};
        dabaoJHLiquid = new Item("dabaoJHLiquid",Color.valueOf("FFE166")){{

        }};
        dabaoyedan = new Item("dabaoyedan",Color.valueOf("fefefe")){{

        }};
        dabaocobo = new Item("dabaocobo",Color.valueOf("5a73f4")){{

        }};
        zishi = new Item("zishi",Color.valueOf("983cff")){{
            hardness = 9;
        }};
        daboayan = new Item("daboayan",Color.valueOf("EA0000")){{

        }};
        oreweijing4 = new Item("oreweijing4",Color.valueOf("FF8000")){{

        }};
        tanqianwei = new Item("tanqianwei",Color.valueOf("ffffff")){{

        }};
        tangang = new Item("tangang",Color.valueOf("ffffff")){{

        }};
        medal1 = new Item("medal-silver"){{

        }};
        medal2 = new Item("medal-gold"){{

        }};
        nulls = new Item("null"){{

        }};



//液体
        zhiwujingyou = new Liquid("zhiwujingyou",Color.valueOf("2f5d42")){{
            flammability = 1f;
            temperature = 0.6f;
            heatCapacity = 0f;
            viscosity = 0.9f;
            explosiveness = 0f;
        }};
        zhiwujinghuaye = new Liquid("zhiwujinghuaye",Color.valueOf("CEFFCE")){{
            flammability = 0f;
            temperature = 0f;
            heatCapacity = 0.6f;
            viscosity = 0.2f;
            explosiveness = 0f;
        }};
        jinglianlio = new Liquid("jinglianlio",Color.valueOf("6b675f")){{
            viscosity = 0;
            flammability = 1.2f;
            explosiveness = 1.5f;
            heatCapacity = 0.7f;
            barColor = Color.valueOf("8e8e8c");
            effect = StatusEffects.tarred;
        }};
        moliye = new Liquid("moliye",Color.valueOf("28004D")){{
            flammability = 0f;
            temperature = 0f;
            heatCapacity = 0.5f;
            viscosity = 0.2f;
            explosiveness = 0f;
        }};
        molijinghuaye = new Liquid("molijinghuaye",Color.valueOf("BE77FF")){{
            flammability = 0f;
            temperature = 0f;
            heatCapacity = 1.5f;
            viscosity = 0.2f;
            explosiveness = 0f;
        }};
        JHhejinLiquid = new Liquid("JHLiquid",Color.valueOf("FFE166")){{
            viscosity = 0.5f;//气化
            temperature = 0.6f;//高温
            flammability = 0f;//可燃
            explosiveness = 0f;//爆炸
            heatCapacity = 0f;//低温
            effect = StatusEffects.melting;//状态：融化燃烧
        }};
        suan = new Liquid("suan",Color.valueOf("005e13")){{
            heatCapacity = 0.3f;
        }};
        yuanwan0 = new Liquid("yuanwan",Color.valueOf("9e1c1c")){{
            viscosity = 0.01f;//气化
            temperature = 2f;//高温
            flammability = 2.5f;//可燃
            explosiveness = 3f;//爆炸
            heatCapacity = 0f;//低温
            effect = StatusEffects.melting;//状态：融化燃烧
        }};
        liziye = new Liquid("liziye",Color.valueOf("ff0000")){{
            heatCapacity = 0f;
            temperature = 2f;
            flammability = 2f;
            explosiveness = 3f;
            viscosity = 0.7f;
        }};
        qiangxiaolengqueye = new Liquid("qiangxiaolengqueye",Color.valueOf("ffffff")){{
            flammability = 0f;//可燃性
            temperature = 0f;//温度
            heatCapacity = 3.8f;//装弹速度
            viscosity = 0.8f;//粘度
            explosiveness = 0f;//爆炸
        }};
        cobo = new Liquid("cobo",Color.valueOf("9ebbe3")){{
            flammability = 0f;//可燃性
            temperature = 0f;//温度
            heatCapacity = 0.2f;//装弹速度
            viscosity = 0.6f;//粘度
            explosiveness = 0f;//爆炸
        }};*/

    }
}
